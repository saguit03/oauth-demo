package es.unex.aos.autorizacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutorizacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutorizacionApplication.class, args);
	}

}
