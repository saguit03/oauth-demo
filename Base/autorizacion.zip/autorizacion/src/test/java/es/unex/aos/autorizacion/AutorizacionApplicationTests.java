package es.unex.aos.autorizacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutorizacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
