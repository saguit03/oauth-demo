package es.unex.aos.recursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecursosApplicationTests {

	@Test
	void contextLoads() {
	}

}
